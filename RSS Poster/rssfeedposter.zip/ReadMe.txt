*******************************
RSS Feed Poster
By: vbgamer45
http://www.elkartemods.com
*******************************

Mod Information: 
For Elkarte 1.0.x

Allows you to add RSS Feed Posting Bots to your forum.
You can either use a real cron job
Using the following file
http://www.yourforums.com/cronrss.php

Or you can run fake cron jobs via php

Allows multiple posting bots
Set Poster Name Or Member Id for the bot
Topic Prefix option
Option to lock topics
Option to enable/disable html in the feed post
Set the update time in minutes
Set how many items to get from the feed
Choose the forum for the feeds.
No duplicate posts. Posts are hashed and stored as a hash.


Other mods can be found at ElkarteMods.com
Include:
elkartemods.com
Include:
ezGallery
Download System
Simple Audio Video Embeder
Registered Links

