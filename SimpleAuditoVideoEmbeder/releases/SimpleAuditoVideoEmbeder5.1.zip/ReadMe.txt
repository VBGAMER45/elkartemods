*******************************
Simple Audio Video Embedder
By: vbgamer45
http://www.elkartemods.com
*******************************

Mod Information: 
For Elkarte 1.1.x and 1.0.x
An auto embed media modification for that takes links for popular video websites and adds a player directly into the post or bbc area of your website

Supports over 90+ sites such as 
Youtube	
Facebook	
Instagram
Vimeo
College Humor
And many more!

Install Information:
Install via the Elkarte's Package Manager via upload package.


############################################
License Information:
Links to http://www.elkartemods.com must remain unless
branding free option is purchased.
#############################################


