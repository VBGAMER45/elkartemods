Discord Whos Online
By: vbgamer45

For: Elkarte 1.1.x

Adds who is online for a discord channel below who's online a forum.
Requires the Server Widget to be enabled under the Widget section for the channel settings.


Based on the idea from Arantor/StoryBB.


https://www.elkartemods.com