*******************************
Download System Lite
By: vbgamer45
http://www.elkartemods.com
*******************************

Mod Information: 
For Elkarte 1.1.x and 1.0.x

A complete download system for Elkarte.


Includes:
Uploadable or linked downloads
Approval of downloads option
Reporting of downloads
Option to have comments on an download
Subcategory support
Ability to rate downloads
Who is viewing download or category
Category level permissions by membergroups
File space manager to see which users are using up the most space
Options to control category display settings
Options to control download display settings
Linking code options

Included icons are from Silk Icons 1.3 available at http://www.famfamfam.com/lab/icons/silk/

############################################
License Information:

Links to http://www.elkartemods.com must remain unless
branding free option is purchased.
#############################################

Other mods can be found at
elkartemods.com
Include:
ezGallery
Simple Audio Video Embeder
Registered Links

