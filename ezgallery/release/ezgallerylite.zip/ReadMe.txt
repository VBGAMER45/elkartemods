*******************************
ezGallery Lite
By: vbgamer45
http://www.elkartemods.com
*******************************

Mod Information: 
For ElkArte 1.1.x and 1.0.x

Install Information:
Goto your package manager upload and then install the addon.
Then afterwords make the gallery directory writable.


A basic photo gallery system for ElkArte.
Features:
Categories
Comment System
Picture Approval
Reporting of Picture.
Permissions for adding/editing/approving/deleting and more
And much more...


############################################
License Information:
ezGallery is NOT free software.

Links to http://www.elkartemods.com must remain unless
branding free option is purchased.
#############################################

Other mods can be found at
ElkarteMods.com
Include:
Download System
RSS Feed Poster
Reglinks
Simple Audio Video Embedder