<?php
header("Location: ../index.php?action=gallery")
?>