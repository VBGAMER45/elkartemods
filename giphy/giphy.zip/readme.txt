Giphy for SMF
By: vbgamer45

For: SMF 2.1.x

Adds a fun way to search for animated gifs in the message editor for user posts powered by Giphy!

Please get your own API key at https://developers.giphy.com to avoid being rated limited!!!


https://www.smfhacks.com