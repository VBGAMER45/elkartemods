Count Child Child Boards Posts

Counts n level child board posts, and shows the last post updated as well.
Adds a setting under modSettings for child board posts


Tip and Trick Converted to Mod from RF-FH
https://www.simplemachines.org/community/index.php?topic=365862.msg3005499#msg3005499

License: BSD License