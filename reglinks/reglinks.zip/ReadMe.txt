*******************************
Registered Links Version 3.0
By: vbgamer45
http://www.elkartemods.com
*******************************

Mod Information: 
For Elkarte 1.1.x and 1.0.x

Allows you stop guests from viewing links. Informs them to register or login.

Other mods:
ezGallery
Simple Audio Video Embedder
Download System
RSS Feed Poster

https://www.elkartemods.com
