<?php
/*
Registered Links
Version 3.0
by:vbgamer45
http://www.elkartemods.com


*/

$txt['no_view_links'] = 'You are not allowed to view links.';
$txt['txt_reg_links_register'] = 'Register';
$txt['txt_reg_links_login'] = 'Login';
$txt['txt_reg_links_or'] = 'or';

	
?>